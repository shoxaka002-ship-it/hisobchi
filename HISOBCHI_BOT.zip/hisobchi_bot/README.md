# HISOBCHI BOT

Render build: `pip install -r requirements.txt`
Render start: `python main.py`

Render Environment Variables:
- `BOT_TOKEN`: BotFather token (maxfiy, GitHub'ga yozmang)
- `ADMIN_ID`: admin Telegram ID, hozir 6945521821

Botda `/admin` yuboring. Admin karta qo‘shish formati:
`VISA|karta raqami|karta egasi|bank`
yoki
`UZCARD|karta raqami|karta egasi|bank`

TON hamyonini admin panelidan yangilash mumkin.

MUHIM: bu birinchi versiyada VISA/UZCARD va TON to‘lovlari chek yoki tranzaksiya ma’lumoti orqali admin tomonidan qo‘lda tekshiriladi. Avtomatik karta to‘lovi uchun bank/to‘lov provayderining API integratsiyasi kerak; TON avtomatik tekshiruvi uchun ham TON API integratsiyasi kerak. Render bepul workerida lokal SQLite ma’lumotlari restart/deployda yo‘qolishi mumkin; doimiy hisob uchun persistent disk yoki PostgreSQL kerak.
